package com.springboot.aopservices;

public interface PaymentService {
	
	public void makePayment();
	

}
